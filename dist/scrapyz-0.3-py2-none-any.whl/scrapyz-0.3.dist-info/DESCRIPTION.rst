Scrapyz is a scrapy extension.


